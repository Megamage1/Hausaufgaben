# Serializer Demo

Start `Program` to see what happens. Either activate jacksonXML or javaNative method.  