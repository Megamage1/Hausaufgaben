import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class PathChange {
    public static void main(String[] args) throws IOException {
//        Path p = Paths.get("D:\\", "temp","../tmp","toonlink.jpg");
//        System.out.printf("Vor Normalisierung: %s%n", p);
//        p=p.normalize();
//        System.out.printf("Nach Normalisierung: %s%n", p);


//        Path p1 = Paths.get("C:/tmp");      //absoluter pfad deshalb p2p1 wird nicht noch ein ordner vorher gezeigt
//        Path p2 = Paths.get("Test.txt");
//        Path p1p2 = p1.resolve(p2);
//        System.out.printf("Gesamtpfad (p1+p2): %s%n", p1p2);
//        Path p2p1 = p2.resolve(p1);
//        System.out.printf("Gesamtpfad (p1+p2): %s%n", p2p1);

//        Path p1 = Paths.get("C://tmp");
//        Path p2 = Paths.get("C://temp/test");
//        Path p1p2 = p1.relativize(p2);
//        System.out.printf("Relativpfad (p1 zu p2): %s%n", p1p2);
//        Path p2p1 = p2.relativize(p1);
//        System.out.printf("Relativpfad (p2 zu p1): %s%n", p2p1);

//        Path p1 = Paths.get("C://tmp/Test.txt");
//        Path p2 = Paths.get("C://tmp/TempTest.txt");
//        Files.copy(p1,p2);


        Files.readAllLines("D:\\IBW_Dok\\Datenbanken\\Aufgaben\\scientistsDB\\src", "names.cs");
        // new scientist mit constructor und aus csv datei reinladen!
        //OPENOLAT datei und csv auch dabei

    }



}
