public final class ConsoleIO{
    public static void main(String[] args) {
        java.io.Console in = System.console();
        

        while(true){
            System.out.println();
            System.out.println("Bitte geben Sie eine Zahl zwischen 1 und 10 ein");
            String text = in.readLine("(Abbruch mit 'q'): %n");
            if("q".equalsIgnoreCase(text)){
                System.out.println("Auf Wiedersehen.");
                break;
            }
            int guess;
            try{
                guess = Integer.parseInt(text);
            }catch (NumberFormatException ex){
                System.out.println("Keine Zahl");
                continue;
            }
            if (guess < 1 || guess > 10) {
                System.out.println("Keine Zahl im Bereich");
                continue;
            }
            int target = (int)(Math.random() * 9) + 1;
            if(guess != target){
                System.out.println("Leider falsch.");
                continue;
            }
            System.out.println("Bravo Zahl gefunden");
            break;
        }
        System.out.println("Auf wiedersehen");
        
    }
}
