import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.FileSystems;
import java.nio.file.Path;

public class FileNIO {
    public static void main(String[] args) throws IOException {
        System.out.println("File Store:");

        for(FileStore fs: FileSystems.getDefault().getFileStores()){
            System.out.printf("'%s' [%s]: %d Bytes %n", fs.name(), fs.type(),
                    fs.getTotalSpace());
        }
        System.out.println();
        System.out.println("Root directories:");
        for(Path p : FileSystems.getDefault().getRootDirectories()){
            System.out.printf("Directory %s%n", p);
        }
        Path p1 = FileSystems.getDefault().getPath("D:\\toonlink.jpg");
    }
}
