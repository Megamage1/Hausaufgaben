public class scientists {

    private final Gender gender;
    private final String firstName;
    private final String lastName;
    private final String dateOfBirth;
    private final String dateOfDeath;


    public scientists(Gender gender, String firstName, String lastName, String dateOfBirth, String dateOfDeath) {
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.dateOfDeath = dateOfDeath;
    }



    @Override
    public String toString(){
        return firstName + " " + lastName + " (" + dateOfBirth + " - " + dateOfDeath + ")";
    }
}
