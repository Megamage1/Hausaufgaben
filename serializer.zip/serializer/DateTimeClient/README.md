### build
`mvn install`

### run
`java -cp target/*.jar ch.ibw.clientServer.client.javaReply.DateTimeClient 127.0.0.1 6060`
